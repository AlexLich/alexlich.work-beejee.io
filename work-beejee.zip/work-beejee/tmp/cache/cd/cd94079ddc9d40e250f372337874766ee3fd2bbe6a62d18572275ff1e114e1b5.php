<?php

/* comment.html.twig */
class __TwigTemplate_5cb23c7d907b6bd5c1f30c14c1f1a7f96f0bbd7d38bcfdc0f446ac66e873eb92 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"panel panel-default\">
    <div class=\"panel-heading\">";
        // line 2
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "username", array()), "html", null, true);
        echo "
        <a href=\"mailto:#\">";
        // line 3
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "email", array()), "html", null, true);
        echo "</a>
        ";
        // line 4
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "created_at", array()), "html", null, true);
        echo "
        ";
        // line 5
        if (($this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "changed_by_admin", array()) == 1)) {
            // line 6
            echo "            <span class=\"label label-info\">Изменен администратором</span>
        ";
        }
        // line 8
        echo "
        ";
        // line 9
        if ((isset($context["isAuth"]) ? $context["isAuth"] : null)) {
            // line 10
            echo "
            ";
            // line 11
            if (($this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "accepted", array()) == 1)) {
                // line 12
                echo "                <span class=\"label label-success\">Принят</span>
            ";
            } else {
                // line 14
                echo "                <span class=\"label label-danger\">Отклонен</span>
            ";
            }
            // line 16
            echo "
        ";
        }
        // line 18
        echo "
    </div>

    <div class=\"panel-body\">
        <p style=\"white-space: pre-wrap;\">";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "body", array()), "html", null, true);
        echo "</p>
    </div>

    ";
        // line 25
        if (($this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "image", array()) != null)) {
            // line 26
            echo "        <div class=\"panel-body\">
            <img src=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "image", array()), "html", null, true);
            echo "\" alt=\"\"/>
        </div>
    ";
        }
        // line 30
        echo "
    ";
        // line 31
        if ((isset($context["isAuth"]) ? $context["isAuth"] : null)) {
            // line 32
            echo "        <div class=\"panel-body\">
            <a href=\"/edit/";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "id", array()), "html", null, true);
            echo "\">Редактировать</a>
        </div>
    ";
        }
        // line 36
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "comment.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 36,  93 => 33,  90 => 32,  88 => 31,  85 => 30,  79 => 27,  76 => 26,  74 => 25,  68 => 22,  62 => 18,  58 => 16,  54 => 14,  50 => 12,  48 => 11,  45 => 10,  43 => 9,  40 => 8,  36 => 6,  34 => 5,  30 => 4,  26 => 3,  22 => 2,  19 => 1,);
    }

    public function getSource()
    {
        return "<div class=\"panel panel-default\">
    <div class=\"panel-heading\">{{comment.username}}
        <a href=\"mailto:#\">{{comment.email}}</a>
        {{comment.created_at}}
        {% if comment.changed_by_admin == 1 %}
            <span class=\"label label-info\">Изменен администратором</span>
        {% endif %}

        {% if isAuth %}

            {% if comment.accepted == 1 %}
                <span class=\"label label-success\">Принят</span>
            {% else %}
                <span class=\"label label-danger\">Отклонен</span>
            {% endif %}

        {% endif %}

    </div>

    <div class=\"panel-body\">
        <p style=\"white-space: pre-wrap;\">{{comment.body}}</p>
    </div>

    {% if comment.image != null %}
        <div class=\"panel-body\">
            <img src=\"{{comment.image}}\" alt=\"\"/>
        </div>
    {% endif %}

    {% if isAuth %}
        <div class=\"panel-body\">
            <a href=\"/edit/{{comment.id}}\">Редактировать</a>
        </div>
    {% endif %}
</div>
";
    }
}
