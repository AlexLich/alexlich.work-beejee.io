<?php

/* login.html.twig */
class __TwigTemplate_e85d17e29fcbd427ab1b7441a0565528554138fe8f2e57e3b81194db52724742 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "login.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Login";
    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
    }

    // line 6
    public function block_content($context, array $blocks = array())
    {
        // line 7
        echo "    <div class=\"panel panel-default\">
        <div class=\"panel-body\">
            <form role=\"form\" action=\"/login\" method=\"post\">
                <div class=\"form-group\">
                    <label for=\"username\">Username</label>
                    <input type=\"text\" class=\"form-control\" name=\"username\" placeholder=\"Enter username\">
                </div>
                <div class=\"form-group\">
                    <label for=\"password\">Пароль</label>
                    <input type=\"password\" class=\"form-control\" name=\"password\" placeholder=\"Password\">
                </div>
                <button type=\"submit\" class=\"btn btn-default\">Отправить</button>
            </form>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 7,  46 => 6,  39 => 4,  36 => 3,  30 => 2,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}
{% block title %}Login{% endblock %}
{% block head %}
    {{ parent() }}
{% endblock %}
{% block content %}
    <div class=\"panel panel-default\">
        <div class=\"panel-body\">
            <form role=\"form\" action=\"/login\" method=\"post\">
                <div class=\"form-group\">
                    <label for=\"username\">Username</label>
                    <input type=\"text\" class=\"form-control\" name=\"username\" placeholder=\"Enter username\">
                </div>
                <div class=\"form-group\">
                    <label for=\"password\">Пароль</label>
                    <input type=\"password\" class=\"form-control\" name=\"password\" placeholder=\"Password\">
                </div>
                <button type=\"submit\" class=\"btn btn-default\">Отправить</button>
            </form>
        </div>
    </div>
{% endblock %}
";
    }
}
