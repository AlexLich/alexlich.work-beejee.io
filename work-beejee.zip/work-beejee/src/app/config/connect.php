<?php
namespace App\Config;

use PDO;

class Connect
{


    public function getDb() {

        $db_host = "mysql.u0151438.z8.ru";
        $db_user="dbu_u0151438_1";
        $db_pass="s5KIJ33LLR";
        $db_name="db_u0151438_1";

        $db = null;

        try
        {
            $db = new PDO("mysql:host=$db_host;dbname=$db_name;", $db_user, $db_pass);

            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
            catch(PDOException $e) {
            error_log($e->getMessage());
            die("A database error was encountered");
        }

        return $db;
    }
}
