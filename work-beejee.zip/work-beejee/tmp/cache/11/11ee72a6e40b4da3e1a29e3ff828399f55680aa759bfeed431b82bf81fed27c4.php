<?php

/* edit.html.twig */
class __TwigTemplate_36e5e2eb8f93401687d176d6bb151ea2965b5668b44a813710d841dccb9a19fd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Редактирование";
    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
    }

    // line 6
    public function block_content($context, array $blocks = array())
    {
        // line 7
        echo "    <div class=\"col-lg col-md-offset-11\">
        ";
        // line 8
        if ((isset($context["isAuth"]) ? $context["isAuth"] : null)) {
            // line 9
            echo "            <a href=\"/logout\">Logout</a>
        ";
        }
        // line 11
        echo "    </div>

    <div class=\"panel panel-default\">
        <div class=\"panel-body\">
            <form id=\"feedback\" enctype=\"multipart/form-data\" action=\"/edit/";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "id", array()), "html", null, true);
        echo "\" method=\"post\" role=\"form\">
                <div class=\"form-group\">
                    <label for=\"email\">Email</label>
                    <input type=\"email\" class=\"form-control\" name=\"email\" value=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "email", array()), "html", null, true);
        echo "\">
                </div>
                <div class=\"form-group\">
                    <label for=\"username\">Name</label>
                    <input type=\"name\" class=\"form-control\" name=\"username\" value=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "username", array()), "html", null, true);
        echo "\">
                </div>

                <div class=\"form-group\">
                    <label for=\"body\">Text</label>
                    <textarea name=\"body\" class=\"form-control\" rows=\"3\">";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "body", array()), "html", null, true);
        echo "</textarea>
                </div>
                ";
        // line 29
        if (($this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "image", array()) != null)) {
            // line 30
            echo "                    <div class=\"panel-body\">
                        <img src=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "image", array()), "html", null, true);
            echo "\" alt=\"\"/>
                    </div>
                ";
        }
        // line 34
        echo "                <div class=\"panel-body\">
                    <div class=\"row\">
                        <div class=\"col-md-1\">
                            <a href=\"/\">Отмена</a>
                        </div>
                        <div class=\"col-md-2\">
                            <input name=\"accepted\" type=\"checkbox\" data-toggle=\"toggle\" data-on=\"Принято\" data-off=\"Отклонено\" data-onstyle=\"success\" data-offstyle=\"danger\" ";
        // line 40
        if (($this->getAttribute((isset($context["comment"]) ? $context["comment"] : null), "accepted", array()) == 1)) {
            echo " checked";
        }
        echo ">
                        </div>
                        <div class=\"col-md-1\">
                            <button type=\"submit\" class=\"btn btn-primary\">Сохранить</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 40,  101 => 34,  95 => 31,  92 => 30,  90 => 29,  85 => 27,  77 => 22,  70 => 18,  64 => 15,  58 => 11,  54 => 9,  52 => 8,  49 => 7,  46 => 6,  39 => 4,  36 => 3,  30 => 2,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}
{% block title %}Редактирование{% endblock %}
{% block head %}
    {{ parent() }}
{% endblock %}
{% block content %}
    <div class=\"col-lg col-md-offset-11\">
        {% if isAuth %}
            <a href=\"/logout\">Logout</a>
        {% endif %}
    </div>

    <div class=\"panel panel-default\">
        <div class=\"panel-body\">
            <form id=\"feedback\" enctype=\"multipart/form-data\" action=\"/edit/{{ comment.id }}\" method=\"post\" role=\"form\">
                <div class=\"form-group\">
                    <label for=\"email\">Email</label>
                    <input type=\"email\" class=\"form-control\" name=\"email\" value=\"{{comment.email}}\">
                </div>
                <div class=\"form-group\">
                    <label for=\"username\">Name</label>
                    <input type=\"name\" class=\"form-control\" name=\"username\" value=\"{{comment.username}}\">
                </div>

                <div class=\"form-group\">
                    <label for=\"body\">Text</label>
                    <textarea name=\"body\" class=\"form-control\" rows=\"3\">{{comment.body}}</textarea>
                </div>
                {% if comment.image != null %}
                    <div class=\"panel-body\">
                        <img src=\"{{comment.image}}\" alt=\"\"/>
                    </div>
                {% endif %}
                <div class=\"panel-body\">
                    <div class=\"row\">
                        <div class=\"col-md-1\">
                            <a href=\"/\">Отмена</a>
                        </div>
                        <div class=\"col-md-2\">
                            <input name=\"accepted\" type=\"checkbox\" data-toggle=\"toggle\" data-on=\"Принято\" data-off=\"Отклонено\" data-onstyle=\"success\" data-offstyle=\"danger\" {% if comment.accepted == 1 %} checked{% endif %}>
                        </div>
                        <div class=\"col-md-1\">
                            <button type=\"submit\" class=\"btn btn-primary\">Сохранить</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
{% endblock %}
";
    }
}
