<?php

/* comments.html.twig */
class __TwigTemplate_dc994a6095c17b61fc5f3056247f4c4c76371a01e182d5a7324d709dc8881171 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "comments.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Отзывы";
    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
    <script src=\"/src/assets/js/feedbackForm.js\"></script>
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "
    <div class=\"col-lg col-md-offset-11\">
        ";
        // line 10
        if (((isset($context["isAuth"]) ? $context["isAuth"] : null) == false)) {
            // line 11
            echo "            <a href=\"/login\">Login</a>
        ";
        }
        // line 13
        echo "
        ";
        // line 14
        if ((isset($context["isAuth"]) ? $context["isAuth"] : null)) {
            // line 15
            echo "            <a href=\"/logout\">Logout</a>
        ";
        }
        // line 17
        echo "    </div>

    <div>
        <strong>Сортировка</strong>
        <div class=\"row\">
            <div class=\"col-md-3\">
                <p>Имени:
                    <a href=\"/?sort=username&orderby=asc\">по возрастанию</a>
                    ,<a href=\"/?sort=username&orderby=desc\">по убыванию</a>
                </p>
            </div>
            <div class=\"col-md-3\">
                <p>Email:
                    <a href=\"/?sort=email&orderby=asc\">по возрастанию</a>
                    ,<a href=\"/?sort=email&orderby=desc\">по убыванию</a>
                </p>
            </div>
            <div class=\"col-md-3\">
                <p>Дате:
                    <a href=\"/?sort=created_at&orderby=asc\">по возрастанию</a>
                    ,<a href=\"/?sort=created_at&orderby=desc\">по убыванию</a>
                </p>
            </div>
        </div>
    </div>

    <div id=\"comments\">
        ";
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["comments"]) ? $context["comments"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
            // line 45
            echo "            ";
            echo twig_include($this->env, $context, "comment.html.twig");
            echo "
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        echo "    </div>

    <div id=\"preview-data\" class=\"panel panel-default\" style=\"display:none\">
        <div class=\"panel-heading\"></div>
        <div class=\"panel-body\"></div>
        <div id=\"image-holder\"></div>
    </div>

    <div class=\"panel panel-default\">
        <div class=\"panel-body\">
            <form id=\"feedback\" enctype=\"multipart/form-data\" action=\"add\" method=\"post\" role=\"form\">
                <div class=\"form-group\">
                    <label for=\"exampleInputEmail\">Email</label>
                    <input type=\"email\" class=\"form-control\" name=\"exampleInputEmail\" placeholder=\"Enter email\">
                </div>
                <div class=\"form-group\">
                    <label for=\"exampleInputName\">Name</label>
                    <input type=\"name\" class=\"form-control\" name=\"exampleInputName\" placeholder=\"Enter name\">
                </div>

                <div class=\"form-group\">
                    <label for=\"text\">Text</label>
                    <textarea name=\"text\" class=\"form-control\" rows=\"3\"></textarea>
                </div>

                <div class=\"form-group\">
                    <input id=\"fileUpload\" type=\"file\" class=\"form-control\" name=\"fupload\" multiple=\"multiple\"/>
                </div>
                <a id=\"preview\" href=\"#\" class=\"btn btn-default\">Предварительный просмотр</a>
                <button type=\"submit\" id=\"save\" class=\"btn btn-primary\">Отправить</button>
            </form>
        </div>
    </div>
    <script>
        file1 = document.getElementById('fileUpload');
        file1.addEventListener('change', function() {
            mime1.innerHTML = file1.files[0].type;
            img1.src = file1.files[0].getAsDataURL();
        }, false);
        form1 = document.getElementById('feedback');
        form1.addEventListener('submit', function(e) {
            if ((/^image\\/.+\$/).test(file1.files[0].type))
            else {
                alert(\"nope, not allowing; it's not an image\");
                e.preventDefault();
            }
        }, false);
    </script>
";
    }

    public function getTemplateName()
    {
        return "comments.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  132 => 47,  115 => 45,  98 => 44,  69 => 17,  65 => 15,  63 => 14,  60 => 13,  56 => 11,  54 => 10,  50 => 8,  47 => 7,  39 => 4,  36 => 3,  30 => 2,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}
{% block title %}Отзывы{% endblock %}
{% block head %}
    {{ parent() }}
    <script src=\"/src/assets/js/feedbackForm.js\"></script>
{% endblock %}
{% block content %}

    <div class=\"col-lg col-md-offset-11\">
        {% if isAuth == false %}
            <a href=\"/login\">Login</a>
        {% endif %}

        {% if isAuth %}
            <a href=\"/logout\">Logout</a>
        {% endif %}
    </div>

    <div>
        <strong>Сортировка</strong>
        <div class=\"row\">
            <div class=\"col-md-3\">
                <p>Имени:
                    <a href=\"/?sort=username&orderby=asc\">по возрастанию</a>
                    ,<a href=\"/?sort=username&orderby=desc\">по убыванию</a>
                </p>
            </div>
            <div class=\"col-md-3\">
                <p>Email:
                    <a href=\"/?sort=email&orderby=asc\">по возрастанию</a>
                    ,<a href=\"/?sort=email&orderby=desc\">по убыванию</a>
                </p>
            </div>
            <div class=\"col-md-3\">
                <p>Дате:
                    <a href=\"/?sort=created_at&orderby=asc\">по возрастанию</a>
                    ,<a href=\"/?sort=created_at&orderby=desc\">по убыванию</a>
                </p>
            </div>
        </div>
    </div>

    <div id=\"comments\">
        {% for comment in comments %}
            {{ include('comment.html.twig') }}
        {% endfor %}
    </div>

    <div id=\"preview-data\" class=\"panel panel-default\" style=\"display:none\">
        <div class=\"panel-heading\"></div>
        <div class=\"panel-body\"></div>
        <div id=\"image-holder\"></div>
    </div>

    <div class=\"panel panel-default\">
        <div class=\"panel-body\">
            <form id=\"feedback\" enctype=\"multipart/form-data\" action=\"add\" method=\"post\" role=\"form\">
                <div class=\"form-group\">
                    <label for=\"exampleInputEmail\">Email</label>
                    <input type=\"email\" class=\"form-control\" name=\"exampleInputEmail\" placeholder=\"Enter email\">
                </div>
                <div class=\"form-group\">
                    <label for=\"exampleInputName\">Name</label>
                    <input type=\"name\" class=\"form-control\" name=\"exampleInputName\" placeholder=\"Enter name\">
                </div>

                <div class=\"form-group\">
                    <label for=\"text\">Text</label>
                    <textarea name=\"text\" class=\"form-control\" rows=\"3\"></textarea>
                </div>

                <div class=\"form-group\">
                    <input id=\"fileUpload\" type=\"file\" class=\"form-control\" name=\"fupload\" multiple=\"multiple\"/>
                </div>
                <a id=\"preview\" href=\"#\" class=\"btn btn-default\">Предварительный просмотр</a>
                <button type=\"submit\" id=\"save\" class=\"btn btn-primary\">Отправить</button>
            </form>
        </div>
    </div>
    <script>
        file1 = document.getElementById('fileUpload');
        file1.addEventListener('change', function() {
            mime1.innerHTML = file1.files[0].type;
            img1.src = file1.files[0].getAsDataURL();
        }, false);
        form1 = document.getElementById('feedback');
        form1.addEventListener('submit', function(e) {
            if ((/^image\\/.+\$/).test(file1.files[0].type))
            else {
                alert(\"nope, not allowing; it's not an image\");
                e.preventDefault();
            }
        }, false);
    </script>
{% endblock %}
";
    }
}
