<?php
namespace App\Model;

class Comment
{
    public $id;
    public $username;
    public $email;
    public $body;
    public $changed_by_admin;
    public $accepted;
    public $image;
    public $datetime;
}
