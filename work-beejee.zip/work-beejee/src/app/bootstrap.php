<?php
use App\Config\Router;
$router = new Router();
$router->routing();
