<?php
namespace App\Core;

class Model
{
    function __construct()
    {
    }
}
